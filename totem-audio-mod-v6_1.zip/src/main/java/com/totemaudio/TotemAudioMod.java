package com.totemaudio;

import com.totemaudio.config.TotemConfig;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

import javax.sound.sampled.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TotemAudioMod implements ClientModInitializer {

    public static TotemConfig CONFIG = new TotemConfig();
    public static final Map<UUID, Integer> POPS = new HashMap<>();
    public static volatile boolean PLAYING_OWN = false;

    @Override
    public void onInitializeClient() {
        CONFIG = TotemConfig.load();
    }

    public static boolean isSelf(Entity e) {
        try {
            Player p = Minecraft.getInstance().player;
            return p != null && p.getUUID().equals(e.getUUID());
        } catch (Throwable t) { return false; }
    }

    /**
     * Plays .wav, .mp3, or .ogg at custom volume/pitch.
     * MP3/OGG are decoded via javax.sound (SPI) or fallback to ffmpeg if available.
     * Never crashes the game — all errors silently swallowed.
     */
    public static void playWav(String fileName, float volume, float pitch) {
        Path file = TotemConfig.soundsFolder().resolve(fileName);
        if (!Files.isRegularFile(file)) return;
        final float vol = Math.max(0f, Math.min(2f, volume));
        final float pit = Math.max(0.25f, Math.min(4f, pitch));
        Thread t = new Thread(() -> {
            try {
                // Try javax.sound first (works for WAV natively, MP3/OGG if SPI libs present)
                playWithJavax(file, vol, pit);
            } catch (Throwable e1) {
                // Fallback: decode to temp WAV via ffmpeg then play
                try {
                    playWithFfmpeg(file, vol, pit);
                } catch (Throwable ignored) {}
            }
        }, "TotemAudio-Play");
        t.setDaemon(true);
        t.start();
    }

    private static void playWithJavax(Path file, float vol, float pit) throws Exception {
        try (AudioInputStream raw = AudioSystem.getAudioInputStream(file.toFile())) {
            AudioFormat src = raw.getFormat();
            AudioFormat pcm = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED,
                    src.getSampleRate(), 16, src.getChannels(),
                    src.getChannels() * 2, src.getSampleRate(), false);
            try (AudioInputStream in = AudioSystem.getAudioInputStream(pcm, raw)) {
                AudioFormat out = new AudioFormat(pcm.getSampleRate() * pit,
                        16, pcm.getChannels(), true, false);
                SourceDataLine line = AudioSystem.getSourceDataLine(out);
                line.open(out);
                line.start();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) {
                    applyVolume(buf, n, vol);
                    line.write(buf, 0, n);
                }
                line.drain();
                line.close();
            }
        }
    }

    private static void playWithFfmpeg(Path file, float vol, float pit) throws Exception {
        // Decode to raw PCM 16-bit stereo 44100hz via ffmpeg
        ProcessBuilder pb = new ProcessBuilder(
                "ffmpeg", "-i", file.toAbsolutePath().toString(),
                "-f", "s16le", "-ar", "44100", "-ac", "2", "pipe:1"
        );
        pb.redirectErrorStream(true);
        Process proc = pb.start();
        AudioFormat fmt = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED,
                44100 * pit, 16, 2, 4, 44100 * pit, false);
        SourceDataLine line = AudioSystem.getSourceDataLine(fmt);
        line.open(fmt);
        line.start();
        try (InputStream is = proc.getInputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) {
                applyVolume(buf, n, vol);
                line.write(buf, 0, n);
            }
        }
        line.drain();
        line.close();
        proc.destroy();
    }

    private static void applyVolume(byte[] buf, int len, float vol) {
        for (int i = 0; i + 1 < len; i += 2) {
            int smp = (short) ((buf[i] & 0xFF) | (buf[i + 1] << 8));
            smp = Math.max(-32768, Math.min(32767, (int)(smp * vol)));
            buf[i] = (byte) smp;
            buf[i + 1] = (byte) (smp >> 8);
        }
    }
}
